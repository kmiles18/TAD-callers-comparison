import numpy as np
import pandas as pd
import os 
import matplotlib.pyplot as plt
import seaborn as sn
import matplotlib.patches as mpatches

callers=['Armatus','Arrowhead','CaTCH','CHAC','CHDF','ClusterTAD','deDoc','DI','EAST','GMAP','HiCExplorer','HiCseg','IC-Finder','InsulationScore','Matryoshka','MrTADFinder','MSTD','OnTAD','Spectral','SpectralTAD','TADBD','TADbit','TADtree','TopDom']
Case_sensitive_callers=['Armatus','Arrowhead','CaTCH','''Constrained
HAC''','CHDF','ClusterTAD','deDoc','DI','EAST','GMAP','HiCExplorer','HiCseg','IC-Finder','''Insulation
Score''','Matryoshka','MrTADFinder','MSTD','OnTAD','Spectral','SpectralTAD','TADBD','TADbit','TADtree','TopDom']

# colors=['darkslategray','darkcyan','navy','c','cyan','lightgreen','lime','green','black','lightcoral','orange','darkorchid','tomato','chocolate','dodgerblue','darkred']
rainbowcolor=iter(plt.cm.rainbow(np.linspace(0,1,24)))
colors=[]
for i in range(24):
    c=next(rainbowcolor)
    colors.append(c)

dataset=['simulate1','simulate2']

c_len=len(callers)
d_len=len(dataset)
res=np.zeros((c_len,d_len), dtype=int)
noiselist=['0.04','0.08','0.12','0.16','0.20']

res=np.zeros( (len(dataset),len(callers),len(noiselist)), dtype=int )

standard_res=np.zeros( (len(dataset),len(noiselist)), dtype=int )

for data in dataset:
    for noise in noiselist:
        total_number = len(open('../simulate_data/%s/simHiC_TADintervals.chr5.%snoise.txt'%(data,noise), 'r').readlines())
        standard_res[dataset.index(data)][noiselist.index(noise)]=total_number
for data in dataset:
    print('####'+data)
    for caller in callers:
        for noise in noiselist:
            if os.path.exists('../all_TADs/bin/%s/%s.%s.chr5'%(caller,data,noise)):
                total_number = len(open('../all_TADs/bin/%s/%s.%s.chr5'%(caller,data,noise), 'r').readlines())
                res[dataset.index(data)][callers.index(caller)][noiselist.index(noise)] = total_number
            else:
                res[dataset.index(data)][callers.index(caller)][noiselist.index(noise)] = 0


# np.savetxt('3.3_total_number.txt',res,fmt='%g',delimiter='\t')

sn.set(style="ticks", palette="muted", color_codes=True)     #set( )设置主题，调色板更常用
plt.close('all')
fig = plt.figure(figsize=(16,8))
ax = fig.subplots(2,3)
axes=[ax[0][0],ax[1][0],ax[0][1],ax[1][1],ax[0][2],ax[1][2]]
# axes=[]
# for i in range(2):
#     for j in range(3):
#         axes.append(ax[i][j])

cnt=0

for didx in range(len(dataset)):
    sn.despine(ax=axes[cnt])
    axes[cnt].plot(noiselist, standard_res[didx][:], label='standard', linewidth=2,
             color='k', marker='o', markersize=0,linestyle=':')

    for caller in callers:
        axes[cnt].plot(noiselist, res[didx][callers.index(caller)][:], label=caller, linewidth=1, color=colors[callers.index(caller)], marker='o', markersize=3)

    patches = [ mpatches.Patch(color=colors[i], label="{:s}".format(Case_sensitive_callers[i]) ) for i in range(len(colors)) ]
    if cnt==0:
        fig.legend(loc='center',prop={'size': 14},bbox_to_anchor=(0.5,1),ncol=8,frameon=False,shadow=False,handles=patches)
    axes[cnt].set_xlabel('noise level',size=16)
    axes[cnt].set_ylabel('Number of TADs',size=16)
    axes[cnt].tick_params(labelsize=16)
    cnt+=1

c_len=len(callers)
d_len=len(dataset)
res=np.zeros((c_len,d_len), dtype=int)
noiselist=['0.04','0.08','0.12','0.16','0.20']

res=np.zeros( (len(dataset),len(callers),len(noiselist)), dtype=float )


def calculate_TPR(file1,file2):
    # file1 is the gold standard
    if os.path.exists(file2):
        count1 = len(open(file1, 'r').readlines())
        count2 = len(open(file2, 'r').readlines())
        if count1 > 0 and count2 >0:
            tads_1 = pd.read_csv(file1, sep='\t', skiprows=1, header=None)
            tads_2 = pd.read_csv(file2, sep='\t', header=None)
            rep1=set(tads_1[0])|set(tads_1[1])
            rep2=set(tads_2[0])|set(tads_2[1])
            intersectsize = len(set(rep1) & set(rep2))
            unionsize = len(set(rep1))
            return intersectsize / unionsize
        else:
            return 0
    else:
        return 0


for data in dataset:
    print('####'+data)
    for caller in callers:
        for noise in noiselist:
            ji_score = calculate_TPR('../simulate_data/%s/simHiC_TADintervals.chr5.%snoise.txt'%(data,noise),'../all_TADs/bin/%s/%s.%s.chr5'%(caller,data,noise))
            res[dataset.index(data)][callers.index(caller)][noiselist.index(noise)] = ji_score

print(res[0])
print(res[1])

for didx in range(len(dataset)):
    sn.despine(ax=axes[cnt])
    for caller in callers:
        axes[cnt].plot(noiselist, res[didx][callers.index(caller)][:], label=caller, linewidth=2, color=colors[callers.index(caller)], marker='o', markersize=3)

    patches = [ mpatches.Patch(color=colors[i], label="{:s}".format(Case_sensitive_callers[i]) ) for i in range(len(colors)) ]
    # if data=='simulate1':
    #     ax1.legend(loc='center', bbox_to_anchor=(0.5,1.2),ncol=4,frameon=False,shadow=False,handles=patches)
    axes[cnt].set_xlabel('noise level',size=16)
    axes[cnt].set_ylabel('TPR',size=16)
    axes[cnt].tick_params(labelsize=16)
    cnt+=1


c_len=len(callers)
d_len=len(dataset)
res=np.zeros((c_len,d_len), dtype=int)
noiselist=['0.04','0.08','0.12','0.16','0.20']

res=np.zeros( (len(dataset),len(callers),len(noiselist)), dtype=float )


def calculate_FDR(file1,file2):
    # file1 is the gold standard
    if os.path.exists(file2):
        count1 = len(open(file1, 'r').readlines())
        count2 = len(open(file2, 'r').readlines())
        if count1 > 0 and count2 >0:
            tads_1 = pd.read_csv(file1, sep='\t', skiprows=1, header=None)
            tads_2 = pd.read_csv(file2, sep='\t', header=None)
            rep1=set(tads_1[0])|set(tads_1[1])
            rep2=set(tads_2[0])|set(tads_2[1])
            intersectsize = len(set(rep1) & set(rep2))
            unionsize = len(set(rep2))
            return 1-intersectsize / unionsize
        else:
            return 0
    else:
        return 0


for data in dataset:
    print('####'+data)
    for caller in callers:
        for noise in noiselist:
            ji_score = calculate_FDR('../simulate_data/%s/simHiC_TADintervals.chr5.%snoise.txt'%(data,noise),'../all_TADs/bin/%s/%s.%s.chr5'%(caller,data,noise))
            res[dataset.index(data)][callers.index(caller)][noiselist.index(noise)] = ji_score

print(res[0])
print(res[1])

for data in dataset:
    sn.despine(ax=axes[cnt])
    for caller in callers:
        axes[cnt].plot(noiselist, res[dataset.index(data)][callers.index(caller)][:], label=caller, linewidth=2, color=colors[callers.index(caller)], marker='o', markersize=3)

    patches = [ mpatches.Patch(color=colors[i], label="{:s}".format(Case_sensitive_callers[i]) ) for i in range(len(colors)) ]
    # if data=='simulate1':
    #     ax1.legend(loc='center', bbox_to_anchor=(0.5,1.1),ncol=4,frameon=False,shadow=False,handles=patches)
    axes[cnt].set_xlabel('noise level',size=16)
    axes[cnt].set_ylabel('FDR',size=16)
    axes[cnt].tick_params(labelsize=16)
    cnt+=1


axes[0].text(-0.15,1., 'a', transform=axes[0].transAxes,fontdict = {'size': 22, 'color': 'black'})
axes[1].text(-0.15,1., 'b', transform=axes[1].transAxes,fontdict = {'size': 22, 'color': 'black'})
plt.tight_layout()
plt.savefig('Supp_Figure7.jpg',dpi=300,bbox_inches = 'tight')
