double rexp(double lambda);
double rnor(double mu,double sd); 
double rgamma(double alpha);
double rchisq(double t); 
