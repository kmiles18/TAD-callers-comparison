#!/bin/bash

mkdir -p log
mkdir -p output
nohup python3 TAD_boundary_enrichment_analysis.py dCTCF  marks/GSM762842_dCTCF_20HE_0hrs_ChIPSeq.bed >log/dCTCF.log&
nohup python3 TAD_boundary_enrichment_analysis.py SuHw marks/GSM762839_Su_Hw_20HE_0hrs_ChIPSeq.bed >log/SuHw.log&
nohup python3 TAD_boundary_enrichment_analysis_chr.py Fs1hL  marks/GSM1032228_Fs1h_L_Kc_peaks.bed >log/Fs1hL.log&
nohup python3 TAD_boundary_enrichment_analysis.py CP190  marks/GSM762836_CP190_20HE_0hrs_ChIPSeq.bed >log/CP190.log&
nohup python3 TAD_boundary_enrichment_analysis.py BEAF32  marks/GSM762845_BEAF-32_20HE_0hrs_ChIPSeq.bed >log/BEAF32.log&
nohup python3 TAD_boundary_enrichment_analysis.py Ttk96k  marks/GSM853474_2011-1007_2011-1008.merged_2011-1098_peaks.bed >log/Ttk96k.log&
